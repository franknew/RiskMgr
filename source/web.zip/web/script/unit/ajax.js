/**
 * ajax请求
 * @authors viktorli (i@lizhenwen.com)
 * @date    2015-07-14 21:27:12
 */

define(function(require, exports, module){
	var $ = require('jquery');

	var MOD = {
		request:function(conf) {
			
			conf.url = this._formatUrl(conf.url);
			//conf.success = this._formatSuccess(conf.success);
			//conf.error = this._formatSuccess(conf.error);
			$.ajax(conf);
		},
		post:function(conf) {

		},
		_formatUrl:function(url) {
			var rs = url;

			return rs;
		},
		_formatSuccess:function(success) {
			if (!success) {
				return success;
			}

			var tmp = success,
				rs = function() {};
			return rs;
		}
	};
	return MOD;
});