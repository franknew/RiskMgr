/**
 * 登录组件
 * @authors viktorli (i@lizhenwen.com)
 * @date    2015-07-14 19:34:09
 */

define(function(require, exports, module){
	var modal = require('risk/components/modal/index'),
		ajax = require('risk/unit/ajax'),
		$ = require('jquery'),
		tmpl = require('./tmpl');

	var MOD = {
		show:function(conf) {
			modal.show({
				width:'430px',
				'title':'登录',
				content:tmpl.login(),
				cancelValue:'注册',
				cancel:function() {
					alert('注册啊注册')
				},
				ok:function() {
					ajax.request({
						url:'http://203.195.163.209/RiskMgr/SOAServiceHost.svc/Execute/RiskMgr.Api.LogonApi/Logon',
						url:'http://127.0.0.1/cgi/RiskMgr/SOAServiceHost.svc/Execute/RiskMgr.Api.LogonApi/Logon',
						type:'post',
						dataType:'json',
						data:{
							username:$('#username').val(),
							password:$('#password').val(),
						},
						success:function(data, textStatus, jqXHR) {
							console.log(data);
							alert('请求成功，数据：'+JSON.stringify(data,null,1))
						},
						error:function(XMLHttpRequest, textStatus, errorThrown) {
							alert('请求出错：\n'+XMLHttpRequest.status+' , '+errorThrown)
						}
					});
					return true;
				}
			});
		}
	};

	return MOD;
});